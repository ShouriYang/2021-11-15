// Note:   
// 1. set and get    dk what they are , do check later
// 2. difference of collection and schema

const mongoose = require("mongoose");

const doctorSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    name: 
    {
        firstName:{
            type: String,
            required: true
        },
        lastName: String,
    },
    dob: Date,
    address: {
        state:{
            type:String,
            validate:{
                validator:
                function(stateString) {
                    return (stateString.length>=2 && stateString.length<=3) 
                },
                message: 'characters shoube have length between 2 and 3. '
            }
        },
        suburb:String,
        street:String,
        unit: Number,
    },
    numPatients:{
        type: Number,
        validate: {
            validator: function(value) {
                return value>=0}
            ,
            message: 'The value should be a positive number.'
        }
    },
});

module.exports = mongoose.model("Doctors", doctorSchema);