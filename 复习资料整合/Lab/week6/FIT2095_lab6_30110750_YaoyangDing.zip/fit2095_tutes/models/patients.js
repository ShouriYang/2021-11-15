const mongoose = require("mongoose");

const patientSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    fullName: {
        type: String,
        required: true
    },
    doctor: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Doctors'
    },
    age: {
        type: Number,
        validate: {
            validator: function (ageValue) {
                return ageValue >= 0 && ageValue <= 120;
            },
            message: 'Age should be a number between 0 and 120'
        }
    },
    dateOfVisit:{
        type:Date,
        default: Date.now
    },
    caseDescription: {
        type: String,
        validate:{
            validator: function(caseString) {
                return caseString.length>=10
            },
            message: 'case description should be a string with at least 10 characters'
        }
    }
});

module.exports = mongoose.model("Patients", patientSchema);