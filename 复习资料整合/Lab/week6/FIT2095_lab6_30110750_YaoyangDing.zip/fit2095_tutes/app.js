// Import packages
//const  mongodb = require('mongodb');
const express = require('express');
const morgan = require("morgan");
const ejs = require("ejs");
const mongoose = require("mongoose");

// configure express
const app = express();
app.set("PORT", 8080);


app.engine("html", ejs.renderFile);
app.set("view engine", "html");

app.use(express.static("public/image"));
app.use(express.static("public/css"));

app.use(express.urlencoded({extended:false}));
app.use(morgan("common"));


const url = "mongodb://localhost:27017/week6labDB";
const print = console.log;

const Doctor = require("./models/doctors");
const Patient = require("./models/patients");

const viewsPath = __dirname + "/views/";

mongoose.connect(url, function(err){
    if(err) {
        print(err);
        return;
    }
    print("successfully connected");
});

app.get('/', (req,res)=>{
    const filePath = viewsPath+"index.html";
    res.sendFile(filePath);
})

//  Doctor
app.get('/newdoctor', (req,res)=>{
    const filePath = viewsPath + "newdoctor.html";
    res.sendFile(filePath);
});
app.post('/newdoctor', (req,res)=>{
    const doctorDetails = req.body;
    let d = new Doctor({
        _id: new mongoose.Types.ObjectId(),
        name:{
            firstName: doctorDetails.firstName,
            lastName: doctorDetails.lastName,
        },
        dob: doctorDetails.date,
        address: {
            state:  doctorDetails.state,
            suburb: doctorDetails.suburb,
            unit:   doctorDetails.unit,
        },
        numPatients: doctorDetails.numberOfPatients
    })
    d.save(function (err) {
        if (err){
            const filePath = viewsPath+"invalidData.html";
            res.sendFile(filePath);
        }else{
            console.log("Doctor saved");
            res.redirect('/listdoctors');
        }
    });
    // console.log(doctorDetails.firstName)
})
app.get('/listdoctors', (req,res) => {
    Doctor.find({}, (err,data)=> {
        res.render("listdoctors.html", {doctorDB:data})
    })
});
app.get('/updatedoctor', (req, res)=> {
    const filePath= viewsPath+"updatedoctor.html";
    res.sendFile(filePath);
})
app.post('/updatedoctor', (req,res)=>{
    const updateDetails = req.body; 
    Doctor.updateOne({_id: updateDetails.doctorID},
                    {$set: {numPatients: updateDetails.numberOfPatient}},
                    function(err, doc) {
                        res.redirect('/listdoctors');
                    });
});


// Patient 
app.get('/newpatient', (req,res)=>{
    const filePath = viewsPath + "newpatient.html";
    res.sendFile(filePath);
});
app.post('/newpatient', (req,res)=>{
    const paitientDetails = req.body;
    let p = new Patient({
        _id: new mongoose.Types.ObjectId(),
        fullName: paitientDetails.fullName,
        doctor: paitientDetails.id,
        age: paitientDetails.age,
        dateOfVisit: paitientDetails.dateOfVisit,
        caseDescription: paitientDetails.case
    });
    p.save((err)=>{
        if (err) {
            const filePath = viewsPath+"invalidData.html";
            res.sendFile(filePath);
        }else{
            // increase number of patient by 1
            Doctor.updateOne({_id: paitientDetails.id}, {$inc: {numPatients:1}},function(err, doc){});
            console.log('Patient saved');
            res.redirect('/listpatients')
        }
    })
});

app.get('/listpatients', function(req,res){
    Patient
    .find({})
    .populate('doctor')
    .exec(function (err,data){
        res.render("listpatients.html", {patientDB:data});
        console.log(data);
    });
})
app.get('/deletepatient', function(req, res){
    filePath = viewsPath + "deletepatient.html";
    res.sendFile(filePath);
})
app.post('/deletepatient', function(req, res){
    const deleteDetails = req.body;
    Patient.deleteOne({fullName: deleteDetails.patientFullName},function(err, doc){
        if (err) throw err;
        res.redirect('/listpatients')
        // update number of patient of doctor
        Doctor.updateOne({_id: toString(Patient.find({fullName: deleteDetails.patientFullName},'doctor'))}, {$dec: {numPatients:1}},function(err, doc){});
    });
});

app.listen(app.get("PORT"), () => {
    console.log("listening on the port："+ app.get("PORT"));
 });

